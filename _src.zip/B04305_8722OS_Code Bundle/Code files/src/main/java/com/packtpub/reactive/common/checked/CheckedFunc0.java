package com.packtpub.reactive.common.checked;

public interface CheckedFunc0<R> {
	R call() throws Exception;
}